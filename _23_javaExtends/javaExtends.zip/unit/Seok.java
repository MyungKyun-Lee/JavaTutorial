package unit;

public class Seok extends StarUnit {

	public void att() {
		System.out.println("seok만 공격으로 -10점");
		super.hp -=10;
	}
	
	@Override
	public void attack() {
		// TODO Auto-generated method stub
		System.out.println("seok만 독자적 공격으로 -500점");
		super.hp -=500;
	}
	
}
