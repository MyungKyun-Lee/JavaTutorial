package unit;

public class ZZan extends StarUnit {
	public String ZZan_name="콩짜장";

	public void att() {
		System.out.println("zzan만 공격으로 -10점");
		super.hp -=100;
	}
	
	@Override
	public void attack() {
		System.out.println("zzan만 독자적 공격으로 -300점");
		super.hp -=300;
	}

}
