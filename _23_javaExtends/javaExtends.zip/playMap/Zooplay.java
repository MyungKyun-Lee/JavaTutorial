package playMap;

import java.util.ArrayList;

import zoounit.Mon;
import zoounit.Ti;
import zoounit.Zooinfo;

public class Zooplay {

	public static void main(String[] args) {
		ArrayList<Zooinfo> zlist = new ArrayList<>();
		
		Zooinfo z = new Ti();
		z.name = "호돌이";
		z.age = 1;
		zlist.add(z);
		z = new Ti();
		z.name = "호순이";
		z.age = 2;
		zlist.add(z);
		z = new Mon();
		z.name = "숭어";
		z.age = 3;
		zlist.add(z);
		for (Zooinfo zz : zlist) {
			zz.eat();
		}
		for (Zooinfo zz : zlist) {
			System.out.println(zz.toString());
		}

	}

}
