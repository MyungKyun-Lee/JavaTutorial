package zoounit;

public class Ti extends Zooinfo {

	
	@Override
	public void eat() {
		// TODO Auto-generated method stub
		super.eat();
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.toString();
	}

	@Override
	public void prt() {
		// TODO Auto-generated method stub
		
	}


}
