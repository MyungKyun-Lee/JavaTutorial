package zoounit;

public abstract class Zooinfo {
	public String zooName="휴먼동물원";
	public String name = null;
	public int age = 1;
	public int kg = 10;
	public abstract void prt(); // 추상머서드, 구현되지 않은 상태
	
	public void eat() {
//		System.out.println("먹이");
	}

	@Override
	public String toString() {
		return "Zooinfo [zooName=" + zooName + ", name=" + name + ", age=" + age + ", kg=" + kg + "]";
	}
	
}
