package main;

import service.wordService;
import view.mainFrame;
import view.viewFrame;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		new mainFrame();
		new viewFrame();
//		new wordService();
	}

}
