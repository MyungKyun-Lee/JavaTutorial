package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import dto.wordDTO;


public class wordDAO {
	private Connection conn = null;
	private String username="system";
	private String password="oracle";
	private String url="jdbc:oracle:thin:@//localhost:1521/ORCL";
	private String driverName="oracle.jdbc.driver.OracleDriver";
	// 싱클톤 디자인 코딩 시작
	public static wordDAO worddao = null; // 자기 자신의 객체 주소 변수
	
	public wordDAO() {
		init();
	}
	public static wordDAO getInstance() {
		if (worddao == null) {
			worddao = new wordDAO();
		}
		return worddao;
	}
	private boolean conn() {
		try {
			conn = DriverManager.getConnection(url,username,password);
			System.out.println("커넥션 자원 획득 성공");
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}
	
	public void add(wordDTO idto) {
		if (conn()) {
			try {
				String sql = "insert into wordlove values(num.nextval,?,?)";
				PreparedStatement psmt = conn.prepareStatement(sql);
				psmt.setString(1, idto.getE_word());
				psmt.setString(2, idto.getH_word());
				// 쿼리 실행
				int resultInt = psmt.executeUpdate();
				if (resultInt > 0) {
					conn.commit();
				} else {
					conn.rollback();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				try {
					if (conn != null) conn.close();
				} catch (Exception e){
					e.printStackTrace();
				}
			}
		
		} else {
			System.out.println("데이터베이스 커넥션 실패");
		}
	}
	
	public void update(wordDTO idto) {
		if (conn()) {
			try {
				String sql = "update wordlove set eword=?, hword=? where num=?";
				PreparedStatement psmt = conn.prepareStatement(sql);
				psmt.setString(1, idto.getE_word());
				psmt.setString(2, idto.getH_word());
				psmt.setInt(3, idto.getNum());
				psmt.executeUpdate();
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				try {
					if (conn != null) conn.close();
				} catch (Exception e){
					e.printStackTrace();
				}
			}
		} else {
			System.out.println("데이터베이스 커넥션 실패");
		}
	}
	
	public void delete(String delNum) {
		if (conn()) {
			try {
				String sql = "delete from wordlove where num=?";
				PreparedStatement psmt = conn.prepareStatement(sql);
				psmt.setString(1, delNum);
				psmt.executeUpdate();
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				try {
					if (conn != null) conn.close();
				} catch (Exception e){
					e.printStackTrace();
				}
			}
		} else {
			System.out.println("데이터베이스 커넥션 실패");
		}
	}
	
	public wordDTO selectEword(String Eword) {
		if (conn()) {
			try {
				String sql = "select * from wordlove where eword like ?";
				PreparedStatement psmt = conn.prepareStatement(sql);
				psmt.setString(1, "%"+Eword+"%");
				ResultSet rs = psmt.executeQuery();
				if (rs.next()) {
					wordDTO wordTemp = new wordDTO();
					wordTemp.setNum(rs.getInt("num"));
					wordTemp.setE_word(rs.getString("eword"));
					wordTemp.setH_word(rs.getString("hword"));
					return wordTemp;
				}
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				try {
					if (conn != null) conn.close();
				} catch (Exception e){
					e.printStackTrace();
				}
			}
			
		} else {
			System.out.println("데이터베이스 커넥션 실패");
		}
		return null;
	}
	
	public wordDTO selectNum(String findNum) {
		if (conn()) {
			try {
				String sql = "select * from wordlove where num=?";
				PreparedStatement psmt = conn.prepareStatement(sql);
				psmt.setString(1, findNum);
				ResultSet rs = psmt.executeQuery();
				if (rs.next()) {
					wordDTO wordTemp = new wordDTO();
					wordTemp.setNum(rs.getInt("num"));
					wordTemp.setE_word(rs.getString("eword"));
					wordTemp.setH_word(rs.getString("hword"));
					return wordTemp;
				}
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				try {
					if (conn != null) conn.close();
				} catch (Exception e){
					e.printStackTrace();
				}
			}
			
		} else {
			System.out.println("데이터베이스 커넥션 실패");
		}
		return null;
	}
	
	public ArrayList<wordDTO> selectAll() {
		ArrayList<wordDTO> flist = new ArrayList<wordDTO>();
		if (conn()) {
			try {
				String sql = "select * from wordlove order by num";
				PreparedStatement psmt = conn.prepareStatement(sql);
				ResultSet rs = psmt.executeQuery();
				while (rs.next()) {
					wordDTO wordTemp = new wordDTO();
					wordTemp.setNum(rs.getInt("num"));
					wordTemp.setE_word(rs.getString("eword"));
					wordTemp.setH_word(rs.getString("hword"));
					flist.add(wordTemp);
				}
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				try {
					if (conn != null) conn.close();
				} catch (Exception e){
					e.printStackTrace();
				}
			}
			
		} else {
			System.out.println("데이터베이스 커넥션 실패");
		}

		return flist;
	}
	
	private void init() {
		try {
			Class.forName(driverName);
			System.out.println("오라클 드라이버 로드 성공");
			
		} catch(ClassNotFoundException e) {
			System.out.println("오라클 드라이버 로드 실패");
			e.printStackTrace();
		}
	}
}
