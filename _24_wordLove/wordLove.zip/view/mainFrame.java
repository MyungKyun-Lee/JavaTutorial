package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyListener;

import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class mainFrame extends JFrame implements ActionListener, KeyListener {

	private JLabel title = new JLabel("단어장 프로그램");
	private JPanel mainP = new JPanel();
	private JPanel leftP = new JPanel();
	private JPanel centerP = new JPanel();
	private JPanel rightP = new JPanel();
	private JButton btn1 = new JButton("East");
	private JButton btn2 = new JButton("West");
	
	public mainFrame() {
		
		this.setBounds(100, 100, 400, 500);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		this.setLayout(new GridLayout(1,3));
		
//		this.add(title,"North");
//		this.add(mainP,"Center");
		
		this.add(leftP);
		leftAdd();
//		this.add(leftP, BorderLayout.NORTH);
		
//		this.add(btn1,"East");
//		this.add(btn2,"West");
//		centerP.setLayout(new BorderLayout());
		centerP.setSize(100, 500);
		centerP.setBackground(Color.red);
		this.add(centerP);
		
//		rightP.setLayout(new BorderLayout());
		rightP.setSize(100, 500);
		rightP.setBackground(Color.CYAN);
		this.add(rightP);
		
		
		this.setVisible(true);
	}
	
	private void leftAdd() {
		// Left 패널
		JLabel label = new JLabel("추가할 단어입력");
		JLabel eLab = new JLabel("영어");
		JLabel hLab = new JLabel("한글");
		JTextField inputE_word = new JTextField(10);
		JTextField inputH_word = new JTextField(10);
		JButton addBtn = new JButton("추가");
		
//		leftP.setLayout(new BorderLayout());
//		leftP.setSize(500, 500);
//		leftP.setBackground(Color.GRAY);
		leftP.setLayout(new GridLayout());
		JPanel center_1 = new JPanel();
		JPanel center_2 = new JPanel();
		JPanel center_3 = new JPanel();
		JPanel center_4 = new JPanel();
		center_1.setBackground(Color.white);
		center_2.setBackground(Color.green);
		center_4.setBackground(Color.red);
		leftP.add(center_1,"North");
		leftP.add(center_2);
		leftP.add(center_3);
		leftP.add(center_4);
		
		center_1.add(label,"North");
		center_2.add(eLab);
		center_2.add(inputE_word);
		center_3.add(hLab);
		center_3.add(inputH_word);
		center_4.add(addBtn);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}
}
