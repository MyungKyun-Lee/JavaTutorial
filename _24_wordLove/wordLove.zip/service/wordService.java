package service;

import java.util.ArrayList;
import java.util.List;

import dao.wordDAO;
import dto.wordDTO;

public class wordService {
	wordDAO worddao = wordDAO.getInstance();
	
	public wordService() {

//		add("chery","체리");
//		wordList();
	}

	public void add(String e_word, String h_word) {
		// DTO 저장
		wordDTO worddto = new wordDTO();
		worddto.setE_word(e_word);
		worddto.setH_word(h_word);
		worddao.add(worddto);
	}
	public void update(String findNum, String e_word, String h_word) {
		wordDTO f = worddao.selectNum(findNum);
		if (f != null) {
			f.setE_word(e_word);
			f.setH_word(h_word);
			worddao.update(f);
		}
		
	}
	public wordDTO selectEword(String Eword) {
		wordDTO f  = worddao.selectEword(Eword);
		if (f != null) {
//			System.out.println(f.getH_word());
//			return f.getH_word();
			return f;
		}
		return null;
	}
	public void del(String delNum) {
//		System.out.println("삭제할 아이디어의 번호를 입력하세요");
//		String delNum = in.nextLine();
		worddao.delete(delNum);
	}
	public ArrayList<wordDTO> wlist() {
		ArrayList<wordDTO> f = worddao.selectAll();
		return f;
		// DB에 저장된 정보를 모두 출력
//		for (wordDTO tempf : f) {
//			c22list.add(tempf.getNum() + ": " + tempf.getE_word()+ tempf.getH_word());
//		}
	}
	
	public void wordList() {  // 전체보기	
		ArrayList<wordDTO> wordlist = worddao.selectAll();
		// DB에 저장된 정보를 모두 출력
		for(wordDTO t : wordlist) {
			System.out.println(t.toString());
		}
	}
}
