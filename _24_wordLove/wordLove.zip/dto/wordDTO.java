package dto;

public class wordDTO {
	private int num =0;
	private String e_word = null;
	private String h_word = null;
	
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public String getH_word() {
		return h_word;
	}
	public void setH_word(String h_word) {
		this.h_word = h_word;
	}
	public String getE_word() {
		return e_word;
	}
	public void setE_word(String e_word) {
		this.e_word = e_word;
	}
	
	@Override
	public String toString() {
		return "wordDTO [num=" + num + ", h_word=" + h_word + ", e_word=" + e_word + "]";
	}
	
}
