package main;

import service.IdeaService;

public class Main {

	public static void main(String[] args) {
		System.out.println("open Idea Info");
		new IdeaService();
//		ideaService ois = new ideaService();
//		ois.menu();

	}

}
