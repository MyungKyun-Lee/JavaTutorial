package main;

import service.IdeaService;
import view.MainFrame;

public class Main {

	public static void main(String[] args) {
		System.out.println("open Idea Info");
//		new IdeaService();
		//		ideaService ois = new ideaService();
		//		ois.menu();
		
		new MainFrame();
	}

}
