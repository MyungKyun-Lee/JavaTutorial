package view;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JTextField;

import dao.IdeaDAO;
import dto.IdeaDTO;
									// 인터페이스 구현 - 기능을 처리하기 위해
public class MainFrame extends JFrame implements ActionListener {
	
	private JLabel title = new JLabel("IdeaBank");
	private JTextField input = new JTextField();
	private JButton btn = new JButton("Save");
//	private List wordList = new List(5,true);
	private List wordList = new List(5,false);
	private JButton btn1 = new JButton("East");
	private JButton btn2 = new JButton("West");
	private JPanel centerP = new JPanel(); // panel은 컨네이너이면서 컴포넌트이다.. 기본 레이아웃이
	
//	private Font f1 = new Font("궁서체",Font.PLAIN, 20);
	
	private IdeaDAO ideaDao = IdeaDAO.getInstance();
	public MainFrame() {
//		super.setBounds(100, 100, 200, 200);  // 일반적으로 this를 많이 사용
		this.setBounds(100, 100, 400, 500);
		// 컨테이너는 컴퍼넌트를 배치시킨다. 컨테이너는 레이아웃이 있다.
		// JFrame은 컨테이너이고, 기본 레이아웃은 border layout이다.
		// border layout은 하나의 공간에 하나의 컴포넌트만 가능하다.
		this.add(title,"North");
		this.add(btn,"South");
		// 가운데 패널
		centerP.setLayout(new BorderLayout());
		centerP.setBackground(Color.red);
		centerP.add(wordList,"Center");
		centerP.add(input,"South");
		this.add(centerP,"Center");
		input.addActionListener(this);

		
//		this.add(wordList,"Center");
//		this.add(btn1,"East");
//		this.add(btn2,"West");
		// 
		btn.addActionListener(this);
		this.setVisible(true);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		loadDB();
	}

	private void loadDB() {
		ArrayList<IdeaDTO> ideadto = ideaDao.selectAll();
		for (IdeaDTO i : ideadto) {
			wordList.add(i.getNum() + " : " + i.getTitle());
		}
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == btn || e.getSource() == input) {
			System.out.println("버튼이 클릭 됨");
			String t = input.getText();
			System.out.println("입력하신 글은 : " + t);

			input.setText("");
//			wordList.setFont(f1);
//			wordList.add(t);
			
			IdeaDTO dto = new IdeaDTO();
			dto.setTitle(t);
			ideaDao.insert(dto);

		}
	}
	
}
