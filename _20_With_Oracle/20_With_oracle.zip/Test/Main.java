package Test;

public class Main {

	public static void main(String[] args) {
		// D:\Workspace\java_src\common
		// insert test
		
		new MemberADM();
		

	}

}
