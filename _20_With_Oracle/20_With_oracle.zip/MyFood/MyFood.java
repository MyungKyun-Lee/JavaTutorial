package MyFood;

public class MyFood {

	public static void main(String[] args) {
		// 내가 좋아 하는 음식을 저장하기
		new MyFoodADM();
	}

}
