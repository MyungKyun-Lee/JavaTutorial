package service;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.List;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import dao_inf.DBdao;
import dto.WordDTO;


public class WordMainFrame extends JFrame implements ActionListener, KeyListener, ItemListener {
	private JPanel title_p = new JPanel();  //컴포넌트&컨테이너. 
	// 기본 레이아웃이 flow 레이아웃.. 가운데부터하나씩 정렬
	private JLabel t = new JLabel("단어장 프로그램" );
	private JPanel center_p = new JPanel();
	private JPanel center_1 = new JPanel();
	private JPanel center_2 = new JPanel();
	private JPanel center_3 = new JPanel();
	
	private JTextField j1 = new JTextField();
	private JTextField j2 = new JTextField();
	private JTextField j5 = new JTextField();
	private JTextField j6 = new JTextField();
	List c22list = new List();

	JButton c1btn  = new JButton("저장");
	JButton c22btn = new JButton("선택단어삭제");
	JButton c5btn  = new JButton("수정");
	
//	DB작업을 위한 인터페이스 변수 선언
	DBdao dbdao = null;
	ArrayList<WordDTO> w = null;
	
	public WordMainFrame(DBdao d){
		this.dbdao = d;
		
		this.setBounds(100, 100, 500, 180);
		title_p.add(t);
		center_p.setBackground(Color.yellow);
		this.add(title_p,"North");
		this.add(center_p,"Center");
		center_1.setBackground(Color.red);
		center_2.setBackground(Color.cyan);
		center_3.setBackground(Color.green);
		// 위 3개의 패널을 center_p 에 추가시키는데
		center_p.setLayout(new GridLayout());
		center_p.add(center_1);
		center_p.add(center_2);
		center_p.add(center_3);
		
		//center_1 작업
		JLabel c1 = new JLabel("단어입력");
		JPanel c1c = new JPanel();
		c1c.setBackground(Color.gray);
		c1c.setLayout(new GridLayout(2, 2));
		JLabel c2 = new JLabel("영어");
		JLabel c3 = new JLabel("한글");
//		JTextField j1 = new JTextField();
//		JTextField j2 = new JTextField();
		c1c.add(c2);
		c1c.add(j1);
		c1c.add(c3);
		c1c.add(j2);
		center_1.setLayout(new BorderLayout());
		center_1.add(c1,"North");
		center_1.add(c1btn,"South");
		center_1.add(c1c,"Center");
		
		c1btn.setActionCommand("insert");
		c1btn.addActionListener(this);
		
		//center_2작업
		JPanel c22 = new JPanel();
		c22.setLayout(new BorderLayout());
		JLabel c22l = new JLabel("단어리스트");
//		List c22list = new List();
		c22.add(c22l,"North");
		c22.add(c22list,"Center");
		c22.add(c22btn,"South");
		center_2.setLayout(new BorderLayout());
		center_2.add(c22,"Center");

		c22list.addItemListener(this); // 리스너등록>이벤트감지
		c22btn.addActionListener(this);

		
		//center_3 작업
		j5.setEnabled(false);  // 영어단어는 수정 안되게 함
		JLabel c5 = new JLabel("단어수정");
		JPanel c5c = new JPanel();
		c5c.setBackground(Color.gray);
		c5c.setLayout(new GridLayout(2, 2));
		JLabel c6 = new JLabel("영어");
		JLabel c7 = new JLabel("한글");
//		JTextField j5 = new JTextField();
//		JTextField j6 = new JTextField();
		c5c.add(c6);
		c5c.add(j5);
		c5c.add(c7);
		c5c.add(j6);
		center_3.setLayout(new BorderLayout());
		center_3.add(c5,"North");
		center_3.add(c5btn,"South");
		center_3.add(c5c,"Center");

		// 영어단어가 나오면 엔터 키값을 받아서 한글을 넣는다
		j5.addKeyListener(this);

		c5btn.setActionCommand("update");
		c5btn.addActionListener(this);
		
		this.setVisible(true);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		init();
	}
	
	private void init() {
		w = dbdao.selectAll();
		for (WordDTO t : w) {
			c22list.add(t.getEng()+" : "+t.getKor());
		}
	}
	
	@Override // 인터페이스를 구현 할 메서드
	public void actionPerformed(ActionEvent e) {
		System.out.println("dddd");
		if (e.getSource() == c1btn) {
			String eng = j1.getText();
			String kor = j2.getText();
			System.out.println(eng+"/"+kor);
			
			//DTO에저장하고 DAO를 통해서 db에 저장..
			WordDTO wdto = new WordDTO();
			wdto.setEng(eng);
			wdto.setKor(kor);
			dbdao.add(wdto);
		} else if (e.getSource() == c5btn) {
			String eng = j5.getText();
			String kor = j6.getText();
			WordDTO wdto = new WordDTO();
			wdto.setEng(eng);
			wdto.setKor(kor);
			dbdao.mod(wdto);
			//
		} else if (e.getSource() == c22btn) {
			String eng = j5.getText();
			WordDTO wdto = new WordDTO();
			wdto.setEng(eng);
			//dao에게 넘겨서 삭제를 합니다. 
			dbdao.delete(wdto);
		}
		
//		wordService wService = new wordService();
		//이벤트가 발생한 버튼에 설정된 action command 읽어오기 
//		String command=e.getActionCommand();
//		if (command.equals("insert")) {
////			System.out.println("버튼이 클릭 됨");
//			String t1 = j1.getText();
//			String t2 = j2.getText();
//			System.out.println("입력하신 글은 : " + t1+ ", " + t2);
////			wordS.add(t1,t2);
//		} else if (command.equals("delete")) {
//			
//		} else if (command.equals("update")) {
//			
//		}
		
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyPressed(KeyEvent e) {
		int code=e.getKeyCode();
	      //엔터키의 코드값인지 확인한다. 
	      if(code == KeyEvent.VK_ENTER) {//만일 엔터키를 눌렀다면
	         //JTextField 에 입력한 문자열을 읽어와서 DefaultListModel 객체에 추가해야 한다. 
	         String Eword=j5.getText();
//	         System.out.println("입력하신 글은 : " + Eword);
//	         wordDTO wordword = wordS.selectEword(Eword);
//	         j5.setText(wordword.getE_word());
//	         j6.setText(wordword.getH_word());
	      }
		
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void itemStateChanged(ItemEvent e) {
		// TODO Auto-generated method stub
		int no = c22list.getSelectedIndex();
		System.out.println(no + "번이 선택 됨");
		WordDTO tempdto = w.get(no);
		j5.setText(tempdto.getEng());
		j6.setText(tempdto.getKor());
	}
	
	
}
