package service;

import dao_inf.DBdao;
import dao_inf.WordDAO_m;

public class WordService {
//	WordDAOoracle worddao = new WordDAO();

	//	DBdao worddao = new WordDAO_m();
	DBdao worddao = null;
	
	public WordService (DBdao db) {
		this.worddao=db;
	}
	public void menu() {
		add();
	}
	
	private void add() {
		// add 데이터베이스 Test
		String a = "test";  // DB작업
		worddao.add(a);
	}
}
