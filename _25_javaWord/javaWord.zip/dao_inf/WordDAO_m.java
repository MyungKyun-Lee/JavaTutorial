package dao_inf;

public class WordDAO_m implements DBdao {

	@Override
	public void add(String d) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String selectAll() {
		// TODO Auto-generated method stub
		return null;
	}

}
