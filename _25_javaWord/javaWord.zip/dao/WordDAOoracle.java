package dao;

public class WordDAOoracle {
	public void add(String d) {
		System.out.println("insert into");
	}
	
	public void selectAll() {
		
	}
}
