package dao;

public class WordDAOmysql {

}
