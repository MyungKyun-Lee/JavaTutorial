package main;

import service.TrainInfo;
import view.MenuFrame;
import view.mainFr;

public class Main {

	public static void main(String[] args) {
		// 기차예약 프로그램 v.03
//		new TrainInfo();
//		new MenuFrame();
		new mainFr();
	}

}
